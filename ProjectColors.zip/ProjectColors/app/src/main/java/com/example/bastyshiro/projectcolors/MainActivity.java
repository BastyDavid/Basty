package com.example.bastyshiro.projectcolors;

import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    TextView textView;
    TextView RojoText0, VerdeText0, AzulText0;
    EditText RojoCuadro0, VerdeCuadro0, AzulCuadro0;
    Button button;
    int valRojo, valVerde, valAzul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);
        textView = (TextView) findViewById(R.id.textView); //asignacion de variables a botones y cuadros de textos
        RojoText0 = (TextView) findViewById(R.id.RojoText);
        VerdeText0 = (TextView) findViewById(R.id.VerdeText);
        AzulText0 = (TextView) findViewById(R.id.AzulText);
        RojoCuadro0 = (EditText) findViewById(R.id.RojoCuadro);
        VerdeCuadro0 = (EditText) findViewById(R.id.VerdeCuadro);
        AzulCuadro0 = (EditText) findViewById(R.id.AzulCuadro);
        button = (Button) findViewById(R.id.Magia);

        button.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          valRojo = Integer.parseInt(RojoCuadro0.getText().toString());

                                          valVerde = Integer.parseInt(VerdeCuadro0.getText().toString());

                                          valAzul = Integer.parseInt(AzulCuadro0.getText().toString());

                                          textView.setBackgroundColor(Color.argb(255, valRojo, valVerde, valAzul));

                                      }

                                  }
        );
    }
}